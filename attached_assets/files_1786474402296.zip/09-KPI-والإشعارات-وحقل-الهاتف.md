# 09 · لوحة KPI · الإشعارات · حقل الهاتف
### التصاميم الكاملة بالكود

> يُقرأ مع الملفّين **07** و**08**.

---

# ⛔ القسم صفر · لا تفعل

| # | ⛔ | لماذا |
|---|---|---|
| 1 | **لا تحوّل لمفاتيح سترايب الحقيقية قبل إتمام الملفّ 08** | القسم 6 |
| 2 | **لا تسمّي قيمة الطلبات «إيرادات»** | القسم 1.2 — خداع محاسبي |
| 3 | **لا تقبل رقم هاتف بلا كود دولة** | القسم 4 — رقم لا يفتح على واتساب |
| 4 | **لا تجعل حقل الهاتف نصّاً حرّاً** | القسم 4 |
| 5 | **لا ترسل بريداً قبل ضبط SPF وDKIM وDMARC** | القسم 5 |
| 6 | **لا تُرسل واتساب آلياً** | القسم 6 — روابط جاهزة فقط |
| 7 | **لا تضع أكثر من خمسة مؤشّرات في الشاشة الرئيسية** | القسم 1 |

---

# القسم 1 · لوحة KPI — `/admin`

## 1.1 · خمسة مؤشّرات فقط

**⛔ لوحة بعشرين رقماً لا يفتحها أحد. خمسة تُقرأ يومياً أنفع.**

```
┌──────────────┬──────────────┬──────────────┬──────────────┬──────────────┐
│  الإيرادات   │  المستحقّات   │ مقاعد قريبة  │ طلبات جديدة  │ إكمال الدفع  │
│  المحصّلة    │  على المتدرّبين│  خلال 14 يوماً│  خلال 7 أيام │  للمقسّطين   │
│              │              │              │              │              │
│  4,250 د.أ   │  1,680 د.أ   │     23       │      12      │     68%      │
│  ▲ 18%       │  ⚠️ 9 متدرّبين│  في 4 دفعات  │  ▲ 3         │  ▼ 5%        │
└──────────────┴──────────────┴──────────────┴──────────────┴──────────────┘
```

| المؤشّر | التعريف الدقيق | لماذا يهمّ |
|---|---|---|
| **الإيرادات المحصّلة** | مجموع `installments.amount_jod` حيث `paid_at IS NOT NULL` — هذا الشهر | ما وصلك فعلاً |
| **المستحقّات** | `SUM(orders.remaining_jod)` لكلّ الطلبات النشطة | **الرقم الذي يكبر وحده ولا ينتبه له أحد** |
| **مقاعد قريبة** | مقاعد شاغرة في دفعات تبدأ خلال 14 يوماً | يحتاج تسويقاً **الآن** |
| **طلبات جديدة** | عدد الطلبات خلال 7 أيام | نبض المبيعات |
| **إكمال الدفع** | نسبة المقسّطين الذين بلغ متبقّيهم صفراً | جودة التحصيل |

## 1.2 · ⛔ قاعدة محاسبية حاسمة

> **«الإيرادات» = ما حُصّل فعلاً. لا قيمة الطلبات.**

مثال: متدرّب سجّل بـ218 ديناراً ودفع 50.

| ✅ الصحيح | ❌ الخطأ |
|---|---|
| إيرادات **50** · مستحقّات **168** | إيرادات **218** |

**الخلط يجعلك تظنّ نفسك رابحاً وأنت لم تقبض بعد.** وهذا أشيع خطأ في لوحات المبيعات.

## 1.3 · بطاقة المؤشّر — الكود

```jsx
<div className="kpi">
  <span className="kpi-label">الإيرادات المحصّلة</span>
  <b className="kpi-value">4,250 <small>د.أ</small></b>
  <span className={`kpi-delta ${up ? 'is-up' : 'is-down'}`}>
    {up ? <TrendingUp size={14}/> : <TrendingDown size={14}/>} {delta}%
    <em>عن الشهر الماضي</em>
  </span>
</div>
```

```css
.kpi-grid{ display:grid; grid-template-columns:repeat(5,1fr); gap:16px }
@media(max-width:1100px){ .kpi-grid{ grid-template-columns:repeat(2,1fr) } }
@media(max-width:600px){  .kpi-grid{ grid-template-columns:1fr } }

.kpi{
  background:var(--card); border:1px solid var(--card-line);
  border-radius:18px; padding:22px 20px;
  display:flex; flex-direction:column; gap:8px;
}
.kpi-label{ font-size:13px; color:var(--t3) }
.kpi-value{
  font-family:'Poppins'; font-size:30px; font-weight:700; color:var(--t1);
  line-height:1; font-variant-numeric:tabular-nums;
}
.kpi-value small{ font-size:14px; color:var(--t3); font-weight:400; margin-inline-start:5px }
.kpi-delta{ display:flex; align-items:center; gap:6px; font-size:12.5px; font-weight:700 }
.kpi-delta.is-up  { color:#6FD79B }
.kpi-delta.is-down{ color:#E8836F }
.kpi-delta em{ font-style:normal; color:var(--t4); font-weight:400 }

/* المستحقّات — تحذيرية دائماً */
.kpi--dues{ border-color:var(--gold-line); background:linear-gradient(180deg,rgba(255,193,7,.08),var(--card) 55%) }
.kpi--dues .kpi-value{ color:var(--gold) }
```

**⛔ ولا تُلوّن المستحقّات بالأحمر** — ليست خطأً بل مالاً في الطريق. الذهبي يقول «انتبه» لا «كارثة».

## 1.4 · ثلاثة تفصيلات تحت

### ① الإيرادات لكلّ دورة

```
أساسيات التعليق — حضوري        ████████████  2,180 د.أ   (10 طلبات)
أساسيات التعليق — مباشر تفاعلي ██████        1,065 د.أ   (7 طلبات)
تمكين اللغة العربية            ███            600 د.أ    (4 طلبات)
```

**يكشف أيّ دورة تجلب مالاً فعلاً، وأيّها تأخذ وقتاً بلا عائد.**

### ② امتلاء الدفعات — أهمّ جدول

```
الدفعة   الدورة              يبدأ بعد   الامتلاء
#137     أساسيات · حضوري      3 أيام    ████████░░  8/10
#141     أساسيات · مباشر     12 يوماً   ██░░░░░░░░  2/10   ⚠️
#201     فن الخطابة          27 يوماً   ███░░░░░░░  3/10
```

**⚠️ تحذير آلي عند:** يبدأ خلال 14 يوماً **و** الامتلاء أقلّ من 50%.

```jsx
const needsPush = daysUntilStart <= 14 && (enrolled / capacity) < 0.5;
```

**وهذا أنفع رقم في اللوحة كلّها** — يخبرك متى تسوّق قبل فوات الأوان.

### ③ مصدر الطلبات

الدولة · النمط · الدورة — لتعرف أين تُنفق تسويقك.

## 1.5 · شريط التنبيهات — أعلى اللوحة

```jsx
{alerts.map(a => (
  <div className={`alert alert--${a.level}`}>
    <AlertTriangle size={16}/>
    <span>{a.text}</span>
    <a href={a.link}>عرض ←</a>
  </div>
))}
```

| التنبيه | المستوى |
|---|---|
| طلب `overbooked` يحتاج تدخّلاً | **حرج** |
| نزاع بنكي (`dispute`) | **حرج** |
| فشل webhook خلال 24 ساعة | **حرج** |
| دفعة تبدأ خلال 3 أيام وامتلاؤها < 50% | تحذير |
| متأخّرون تجاوزوا 14 يوماً | تحذير |
| فشل مزامنة الشيت | معلومة |

---

# القسم 2 · لوحة الإدارة — تكملة الملفّ 08

## 2.1 · الشاشات

```
/admin              لوحة KPI              ← القسم 1
/admin/orders       الطلبات               ← ملفّ 08 · 6.1
/admin/dues         المستحقّات            ← ملفّ 08 · 6.4
/admin/cohorts      الدفعات والمقاعد      ← ملفّ 08 · 6.3
/admin/settings     أسعار الصرف · النصوص
```

## 2.2 · التصميم

```css
.admin{ display:grid; grid-template-columns:236px 1fr; min-height:100vh }
.admin-side{
  background:#111925; border-inline-start:1px solid var(--card-line);
  padding:24px 16px; position:sticky; top:0; height:100vh;
}
.admin-nav a{
  display:flex; align-items:center; gap:11px;
  padding:11px 14px; border-radius:11px;
  color:var(--t3); font-size:14.5px; font-weight:700;
  text-decoration:none; transition:.2s;
}
.admin-nav a:hover{ background:rgba(255,255,255,.05); color:var(--t1) }
.admin-nav a.is-active{ background:var(--gold-soft); color:var(--gold) }
.admin-main{ background:var(--canvas); padding:28px 30px }
@media(max-width:900px){
  .admin{ grid-template-columns:1fr }
  .admin-side{ position:static; height:auto }
  .admin-nav{ display:flex; gap:8px; overflow-x:auto }
}
```

## 2.3 · جدول الطلبات

```css
.tbl{ width:100%; border-collapse:collapse; font-size:14px }
.tbl th{
  background:#111925; color:var(--gold);
  padding:13px 14px; text-align:right; font-weight:700; font-size:13px;
  position:sticky; top:0; z-index:2;
}
.tbl td{ padding:13px 14px; border-bottom:1px solid var(--card-line); color:var(--t2) }
.tbl tr:hover td{ background:var(--card-hi) }
.tbl .num{ font-family:'Poppins'; font-variant-numeric:tabular-nums }
.tbl .due{ color:var(--gold); font-weight:700 }
.tbl .done{ color:#6FD79B }

.badge{ font-size:11.5px; font-weight:700; padding:4px 11px; border-radius:999px }
.badge--paid  { background:rgba(31,157,87,.16);  color:#6FD79B }
.badge--partial{ background:rgba(255,193,7,.16); color:var(--gold) }
.badge--over  { background:rgba(194,69,60,.18);  color:#E8836F }
```

**⛔ والهاتف يُعرض بفاصلة عليا** `'962…` عند التصدير — وإلّا حذف جوجل الصفر.

---

# القسم 3 · تسجيل دفعة يدوية

## المنطق

```ts
async function recordPayment(orderId, { seq, amountJod, method, paidAt, reference }) {
  return db.transaction(async (tx) => {
    const order = await tx.selectForUpdate('orders', orderId);
    const inst  = await tx.getInstallment(orderId, seq);

    if (inst.paid_at)             throw new Error('هذه الدفعة مسجَّلة بالفعل');
    if (amountJod > order.remaining_jod)
      throw new Error(`المبلغ يتجاوز المتبقّي (${order.remaining_jod} د.أ)`);

    await tx.updateInstallment(inst.id, { paid_at: paidAt, method, reference,
                                          recorded_by: currentUser });
    // ⛔ يُحسب من الدفعات لا يدوياً
    const paid = await tx.sumPaidInstallments(orderId);
    await tx.updateOrder(orderId, {
      paid_jod: paid,
      remaining_jod: order.total_jod - paid,
      status: (order.total_jod - paid) <= 0 ? 'completed' : 'partially_paid',
    });
    await tx.logAdminAction('record_payment', orderId, { seq, amountJod, method });
    return tx.getOrder(orderId);
  });
}
```

**⛔ ثلاث قواعد:**
1. **`paid_jod` يُحسب من مجموع الدفعات** — لا يُكتب يدوياً
2. **لا يُقبل مبلغ يتجاوز المتبقّي**
3. **كلّ إجراء يُسجَّل** — من ومتى وماذا. سجلّ مالي

**وبعد الحفظ:** استدعِ `syncOrdersToSheet()` فوراً · وأظهر زرّ **«إرسال تأكيد واتساب»**.

---

# القسم 4 · حقل الهاتف — إصلاح إلزامي

## ⛔ المشكلة في التصميم الحالي

الحقل نصّ حرّ بخانة `+962 7x xxx xxxx`. **والزائر يستطيع كتابة `0791234567` وينجح النموذج.**

**والنتيجة:** رقم بلا كود دولة **لا يفتح على واتساب** — زبون دفع ولا تستطيع الوصول إليه.

## التصميم الصحيح — منتقي منفصل

```
┌──────────────────────┬────────────────────────────────┐
│  🇯🇴 الأردن  +962 ▾  │  7 9123 4567                  │
└──────────────────────┴────────────────────────────────┘
   ↑ منتقي بحث              ↑ أرقام فقط
```

```jsx
<div className="phone-field">
  <button type="button" className="cc-trigger" onClick={() => setOpen(!open)}>
    <span className="cc-flag">{country.flag}</span>
    <span className="cc-name">{country.nameAr}</span>
    <span className="cc-dial">+{country.dial}</span>
    <ChevronDown size={15} />
  </button>

  <input
    type="tel" inputMode="numeric" autoComplete="tel-national"
    value={local}
    onChange={e => setLocal(normalize(e.target.value))}
    placeholder={country.example}
    aria-label="رقم الهاتف بلا كود الدولة"
  />

  {open && (
    <div className="cc-menu" role="listbox">
      <input className="cc-search" autoFocus placeholder="ابحث عن دولتك…"
             value={q} onChange={e => setQ(e.target.value)} />
      <ul>
        {filtered.map(c => (
          <li key={c.iso} role="option" onClick={() => pick(c)}
              className={c.iso === country.iso ? 'is-on' : ''}>
            <span>{c.flag}</span><span>{c.nameAr}</span><span className="dial">+{c.dial}</span>
          </li>
        ))}
      </ul>
    </div>
  )}
</div>
```

## 4.1 · المنطق

```ts
/** يحذف كلّ ما ليس رقماً، ويُسقط الصفر الأوّل */
function normalize(v: string) {
  return v.replace(/\D/g, '').replace(/^0+/, '');
}

/** الرقم الكامل للتخزين والواتساب */
function fullNumber(dial: string, local: string) {
  return dial + normalize(local);          // 962 + 791234567
}
```

**⛔ إسقاط الصفر الأوّل إلزامي.** من يكتب `0791234567` مع كود `962` ينتج `9620791234567` — **رقم غير صالح**.

## 4.2 · الترتيب والافتراضي

| القاعدة | التفصيل |
|---|---|
| **الافتراضي** | 🇯🇴 **الأردن +962** دائماً |
| **الأعلى في القائمة** | الأردن · السعودية · الإمارات · الكويت · قطر · البحرين · عُمان · مصر |
| **ثمّ فاصل** | ــــــــ |
| **ثمّ الباقي** | أبجدياً بالعربية |
| **البحث** | بالاسم العربي أو الإنجليزي أو كود الاتصال |

**⛔ ولا تكتشف الدولة جغرافياً وتغيّر الاختيار تلقائياً** — الزائر قد يكون مسافراً، والتغيير المفاجئ يربكه. الأردن افتراضياً دائماً.

## 4.3 · التحقّق

```ts
const MIN = { '962':9, '966':9, '971':9, '965':8, '20':10, '974':8, '973':8, '968':8 };

function validate(dial: string, local: string) {
  const n = normalize(local);
  if (!n)                    return 'رقم الهاتف مطلوب';
  const min = MIN[dial] ?? 7;
  if (n.length < min)        return `رقم غير مكتمل — يجب أن يكون ${min} أرقام على الأقلّ`;
  if (n.length > 12)         return 'رقم طويل أكثر من اللازم';
  return null;
}
```

**والخطأ يظهر تحت الحقل بنصّ عربي ولون — لا بلون وحده.**

## 4.4 · التنسيق

```css
.phone-field{ display:grid; grid-template-columns:auto 1fr; gap:9px; position:relative }

.cc-trigger{
  display:flex; align-items:center; gap:8px;
  background:var(--cream-card); border:1px solid var(--cream-line);
  border-radius:12px; padding:13px 14px; cursor:pointer;
  font-family:inherit; font-size:14.5px; color:var(--ink); white-space:nowrap;
}
.cc-trigger:hover{ border-color:var(--gold-ink) }
.cc-dial{ font-family:'Poppins'; color:var(--ink-2) }

.phone-field input[type="tel"]{
  direction:ltr; text-align:left;              /* ⛔ الأرقام LTR دائماً */
  font-family:'Poppins'; font-size:16px;       /* ⛔ 16px يمنع تكبير آيفون */
  letter-spacing:.5px;
}

.cc-menu{
  position:absolute; top:calc(100% + 6px); inset-inline-start:0;
  width:min(340px,100%); max-height:320px; overflow-y:auto; z-index:60;
  background:var(--cream-card); border:1px solid var(--cream-line);
  border-radius:14px; box-shadow:0 20px 50px rgba(24,32,47,.18);
}
.cc-search{ position:sticky; top:0; width:100%; padding:13px 15px;
            border:0; border-bottom:1px solid var(--cream-line);
            font-family:inherit; font-size:14.5px; background:var(--cream-card) }
.cc-menu li{ display:flex; align-items:center; gap:11px;
             padding:11px 15px; cursor:pointer; font-size:14.5px }
.cc-menu li:hover{ background:#FBF8F1 }
.cc-menu li.is-on{ background:rgba(255,193,7,.14); font-weight:700 }
.cc-menu .dial{ margin-inline-start:auto; font-family:'Poppins'; color:var(--ink-2) }

@media(max-width:600px){ .phone-field{ grid-template-columns:1fr } }
```

## 4.5 · ⛔ خمس قواعد

| # | القاعدة | بدونها |
|---|---|---|
| 1 | **`font-size:16px`** في حقل الهاتف | آيفون يُكبّر الصفحة عند الضغط |
| 2 | **`direction:ltr`** على حقل الأرقام | الأرقام تنقلب |
| 3 | **`inputMode="numeric"`** | تفتح لوحة حروف لا أرقام |
| 4 | **إسقاط الصفر الأوّل** | رقم غير صالح على واتساب |
| 5 | **إغلاق بـEscape والنقر خارجاً** | القائمة تعلق مفتوحة |

## 4.6 · تحسينات باقي حقول النموذج

من اللقطة، ثلاثة تحسينات:

**① `autocomplete` مفقود** — يجعل التعبئة أسرع بمرّتين على الجوّال:
```html
<input autoComplete="given-name">    <!-- الاسم الأوّل -->
<input autoComplete="family-name">   <!-- اسم العائلة -->
<input autoComplete="email" inputMode="email">
<input autoComplete="address-level2"><!-- المدينة -->
```

**② الحقول الإلزامية** — النجمة `*` وحدها لا تكفي. أضِف `required` و`aria-required="true"`.

**③ زرّ «التالي» معطّل بصرياً** — رمادي بلا سبب ظاهر. اجعله:
- ذهبياً عند اكتمال الحقول الإلزامية
- ومعه سطر تحته عند التعطيل: «أكمل الحقول المطلوبة للمتابعة»

---

# القسم 5 · البريد

## 5.1 · ⛔ قبل أيّ إرسال

| السجلّ | الغرض |
|---|---|
| **SPF** | يُصرّح لخدمة الإرسال بالإرسال باسم نطاقك |
| **DKIM** | توقيع تشفيري يُثبت أنّ الرسالة منك |
| **DMARC** | يُخبر الخوادم بما تفعله عند فشل الأوّلين |

**اختبار حاسم:** أرسل رسالة إلى Gmail. **وصلت الوارد أم Spam؟** — أخبرني بالنتيجة قبل المتابعة.

## 5.2 · قالب موحّد

```
┌────────────────────────────────────┐
│         [لوغو كاسيت]                │   خلفية #1A2533
├────────────────────────────────────┤
│  العنوان                            │   خلفية #F4EFE4
│  التحية والنصّ                       │
│                                    │
│  ┌──────────────────────────────┐  │
│  │  تفاصيل الطلب                 │  │   بطاقة بيضاء
│  │  الدورة · الدفعة · الجدول      │  │   حدّ #FFC107
│  │  المدفوع · المتبقّي            │  │
│  └──────────────────────────────┘  │
│                                    │
│  [ زرّ الإجراء ]                    │
├────────────────────────────────────┤
│  info@kaseet.com · +962 7 9023 4483│   خلفية #111925
│  سياسة الإلغاء والاسترداد           │
└────────────────────────────────────┘
```

**⛔ قواعد HTML للبريد:**
- **جداول لا `flexbox` ولا `grid`** — Outlook لا يدعمهما
- **CSS مضمّن (`inline`)** — لا `<style>` خارجي
- **عرض أقصى 600px**
- **`dir="rtl"` على `<table>` الرئيسي**
- **الألوان صريحة بالسادس عشري** — لا متغيّرات CSS
- **نسخة نصّية عادية (plain text)** مرافقة — بدونها ترتفع احتمالية Spam

## 5.3 · الرسائل الأربع

| # | متى | العنوان | الزرّ |
|---|---|---|---|
| 1 | نجاح الدفع | `تأكيد تسجيلك — {الدورة} ({رقم الطلب})` | تفاصيل طلبي |
| 2 | تسجيل دفعة يدوية | `استلمنا دفعتك — المتبقّي {المبلغ} د.أ` | — |
| 3 | قبل البدء بيومين | `دورتك تبدأ بعد يومين — {الدورة}` | الموقع أو رابط الجلسة |
| 4 | اكتمال السداد | `اكتمل سداد دورتك 🎉` | — |

**⛔ ولا ترسل شيئاً إن لم يُدخِل المتدرّب بريداً** — الحقل اختياري. اكتفِ بالواتساب.

---

# القسم 6 · رسائل واتساب

## ⛔ روابط جاهزة لا إرسال آلي

الإرسال الآلي يحتاج **WhatsApp Business API** وموافقة قوالب — أسابيع. **والرابط الجاهز يعطي 90% من الفائدة بصفر تعقيد.**

```ts
export const WA_TEMPLATES = {
  confirm: (o) => `مرحباً ${o.firstName} 👋
تمّ تثبيت مقعدك في *${o.courseName}* — ${o.modeLabel}

📅 الدفعة #${o.cohortId} · تبدأ ${o.startAr}
🗓 ${o.days} · ${o.timeAr} (بتوقيت عمّان)
👩‍🏫 ${o.trainer}
${o.mode === 'onsite' ? '📍 استوديو كاسيت — عمّان' : '💻 عبر Google Meet'}

💳 المدفوع: ${o.paidJod} ديناراً${o.remainingJod > 0
  ? `\n📌 المتبقّي: *${o.remainingJod} ديناراً* — نرتّبها معك قبل البدء` : ''}

أهلاً بك في كاسيت 🌟`,

  received: (o, amt) => `مرحباً ${o.firstName}،
استلمنا دفعتك بمبلغ *${amt} ديناراً* ✅
${o.remainingJod > 0 ? `المتبقّي: *${o.remainingJod} ديناراً*` : 'اكتمل سداد دورتك 🎉'}
شكراً لك.`,

  reminder: (o) => `مرحباً ${o.firstName}،
تذكير ودّي بدفعة *${o.remainingJod} ديناراً* من دورة *${o.courseName}*.
متى يناسبك ترتيبها؟`,

  starting: (o) => `مرحباً ${o.firstName} 👋
دورتك *${o.courseName}* تبدأ بعد يومين — ${o.startAr} · ${o.timeAr}
${o.mode === 'onsite' ? '📍 استوديو كاسيت — عمّان' : `💻 الرابط: ${o.meetLink}`}
نراك قريباً 🌟`,
};

export const waLink = (phone: string, text: string) =>
  `https://wa.me/${phone}?text=${encodeURIComponent(text)}`;
```

**وأزرار في صفّ الطلب باللوحة:**
```
[ 💬 تأكيد ]  [ 💬 استلام دفعة ]  [ 💬 تذكير ]  [ 💬 قبل البدء ]
```

**والزرّ يُظهر حالة «أُرسل ✓»** بعد النقر — حتى لا تُرسل المستشارة الرسالة مرّتين.

---

# القسم 7 · التحويل لمفاتيح الإنتاج — آخر خطوة

## ⛔ لا تفعلها قبل نجاح هذه كلّها

- [ ] الـwebhook يعمل ويُنشئ طلباً وينقص مقعداً
- [ ] لوحة الإدارة تعمل وتسجّل الدفعات
- [ ] **بريد تجريبي وصل الوارد لا Spam**
- [ ] `/terms` و`/refund-policy` و`/privacy-policy` تفتح فعلاً
- [ ] الدومين مربوط والـwebhook مسجَّل عليه
- [ ] الستّة سيناريوهات في الملفّ 07 نجحت

## خطوات التحويل

1. `sk_live` و`pk_live` في **Secrets** — ⛔ لا في ملفّ
2. **webhook إنتاجي جديد** في لوحة سترايب ← `whsec_` **جديد ومختلف**
3. عملية حقيقية بمبلغ صغير
4. تحقّق من الطلب في القاعدة واللوحة والشيت
5. **استرداد العملية** واختبر `charge.refunded`
6. تحقّق من عودة المقعد

**⛔ وأبقِ مفاتيح الاختبار في بيئة منفصلة** — لا تحذفها.

---

# القسم 8 · قائمة الفحص

## KPI
- [ ] خمسة مؤشّرات فقط في الشاشة الرئيسية
- [ ] **الإيرادات = ما حُصّل فعلاً** لا قيمة الطلبات
- [ ] المستحقّات ذهبية لا حمراء
- [ ] تحذير آلي: يبدأ خلال 14 يوماً وامتلاء < 50%
- [ ] شريط التنبيهات يعرض `overbooked` و`dispute` وفشل webhook

## حقل الهاتف
- [ ] منتقي دولة منفصل + بحث
- [ ] الأردن افتراضياً · الدول العربية أعلى القائمة
- [ ] `font-size:16px` — **اختبر على آيفون: لا يُكبّر الصفحة**
- [ ] `direction:ltr` على حقل الأرقام
- [ ] `inputMode="numeric"` يفتح لوحة أرقام
- [ ] **`079…` يتحوّل إلى `96279…` لا `9620 79…`**
- [ ] التحقّق يرفض الرقم الناقص برسالة عربية
- [ ] إغلاق القائمة بـEscape والنقر خارجاً

## النموذج
- [ ] `autocomplete` على كلّ حقل
- [ ] `required` و`aria-required` على الإلزامية
- [ ] زرّ «التالي» ذهبي عند الاكتمال، ومعه سبب التعطيل

## البريد
- [ ] SPF · DKIM · DMARC مضبوطة
- [ ] **رسالة تجريبية وصلت الوارد**
- [ ] القالب بجداول ونمط مضمّن ونسخة نصّية
- [ ] لا إرسال عند غياب البريد

## واتساب
- [ ] أربعة قوالب جاهزة
- [ ] الأزرار في صفّ الطلب
- [ ] حالة «أُرسل ✓» بعد النقر

---

# القسم 9 · ما ينتظر وجيز

| # | البند | يوقف؟ |
|---|---|---|
| 1 | **أوقات الدفعات 201 و202 و203** | **نعم** — ثلاث دورات لا تُعرض |
| 2 | خدمة إرسال البريد + ضبط DNS | **نعم** |
| 3 | **سياسة الاسترداد منشورة** | **نعم** — سترايب يراجعها |
| 4 | كلمة مرور لوحة الإدارة | **نعم** |
| 5 | روابط Google Meet للدفعات المباشرة | لا |
| 6 | الكتيّبات PDF | لا |
