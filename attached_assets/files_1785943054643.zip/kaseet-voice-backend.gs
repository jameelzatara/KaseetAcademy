/**
 * ═══════════════════════════════════════════════════════════════
 *  كاسيت أكاديمي · نظام «سمّعنا صوتك»
 *  الواجهة الخلفية: Google Apps Script — يكتب في Google Sheet
 *  ويحفظ الملفّ الصوتي في مجلّد Google Drive.
 * ═══════════════════════════════════════════════════════════════
 *
 *  خطوات التركيب (عشر دقائق):
 *
 *  ✅ المعرّفان مضبوطان مسبقاً في CONFIG — لا تُعدّلهما.
 *
 *  1. افتح الشيت: docs.google.com/spreadsheets/d/1g6R_V1eU2xJVZX3eN0-pkGei0fzh550yTa4e_jAuKkg
 *  2. Extensions ← Apps Script
 *  3. الصق هذا الملفّ كاملاً (احذف أيّ كود موجود)
 *  4. شغّل الدالة setupSheet مرّة واحدة — تُنشئ تبويباً باسم submissions
 *     مع رؤوس الأعمدة وقائمة «الحالة» المنسدلة
 *  5. Deploy ← New deployment ← Web app
 *       Execute as:      Me
 *       Who has access:  Anyone            ← إلزامي
 *  6. انسخ رابط الـWeb app والصقه في voice-test.html مكان
 *     var ENDPOINT = '';   ← في أوّل بلوك <script>
 *
 *  ⚠️  عند كلّ تعديل على هذا الملفّ، اعمل Deploy ← Manage deployments
 *      ← Edit ← New version. وإلّا بقي الرابط يعمل بالنسخة القديمة.
 */

var CONFIG = {
  SHEET_ID:  '1g6R_V1eU2xJVZX3eN0-pkGei0fzh550yTa4e_jAuKkg',
  FOLDER_ID: '1vfrSPTk1Qccj8M_yoYditf5QWxZ9xA6U',
  SHEET_NAME: 'submissions',
  NOTIFY_EMAIL: 'info@kaseet.com',   // إشعار داخلي بكلّ تقديم
  WEEKLY_CAP: 20                     // السقف الأسبوعي
};

/* ─────────── رؤوس الأعمدة ─────────── */
var HEADERS = [
  'الوقت','رمز التقييم','الاسم','الواتساب','البريد','الدولة','المدينة',
  'المجال','المستوى','الهدف','موعد البدء',
  'نقاء التسجيل dB','مستوى الصوت dB','نطاق التلوين Hz','نصف نغمة',
  'إدارة النفس ث','وقفات/دقيقة','مدّة التسجيل ث',
  'رابط الملفّ الصوتي','موافقة التسويق','الحالة','المُقيِّم','ملاحظات'
];

/* ─────────── تشغيل مرّة واحدة ─────────── */
function setupSheet() {
  var ss = SpreadsheetApp.openById(CONFIG.SHEET_ID);
  var sh = ss.getSheetByName(CONFIG.SHEET_NAME) || ss.insertSheet(CONFIG.SHEET_NAME);
  sh.clear();
  sh.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS])
    .setFontWeight('bold').setBackground('#1A2533').setFontColor('#FFC107');
  sh.setFrozenRows(1);
  sh.getRange(1, 1, 1, HEADERS.length).setHorizontalAlignment('right');
  ss.setSpreadsheetLocale('ar');

  // قائمة منسدلة لعمود «الحالة» لمتابعة سير العمل
  var statusCol = HEADERS.indexOf('الحالة') + 1;
  var rule = SpreadsheetApp.newDataValidation()
    .requireValueInList(['جديد', 'قيد التقييم', 'أُرسل التقرير', 'تابعنا', 'سجّل', 'لم يردّ'], true)
    .build();
  sh.getRange(2, statusCol, 2000, 1).setDataValidation(rule);

  return 'تمّ إنشاء الشيت بنجاح.';
}

/* ─────────── فحص صحّة الرابط ─────────── */
function doGet() {
  return json({ ok: true, service: 'kaseet-voice-test', remaining: remainingThisWeek() });
}

/* ─────────── استقبال التقديم ─────────── */
function doPost(e) {
  try {
    if (!e || !e.postData || !e.postData.contents) {
      return json({ ok: false, error: 'EMPTY_BODY', msg: 'لم تصل بيانات.' });
    }

    var d = JSON.parse(e.postData.contents);

    // تحقّق من الحقول الإلزامية
    var need = ['name', 'phone', 'email', 'country', 'category'];
    for (var i = 0; i < need.length; i++) {
      if (!d[need[i]] || String(d[need[i]]).trim() === '') {
        return json({ ok: false, error: 'MISSING_FIELD', field: need[i], msg: 'حقل مطلوب ناقص.' });
      }
    }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(d.email)) {
      return json({ ok: false, error: 'BAD_EMAIL', msg: 'البريد الإلكتروني غير صحيح.' });
    }
    if (!d.consent) {
      return json({ ok: false, error: 'NO_CONSENT', msg: 'الموافقة على معالجة البيانات مطلوبة.' });
    }

    // السقف الأسبوعي
    var left = remainingThisWeek();
    if (left <= 0) {
      return json({ ok: false, error: 'CAP_REACHED', msg: 'اكتمل عدد هذا الأسبوع.' });
    }

    // منع التكرار: نفس البريد خلال 24 ساعة
    if (isDuplicate(d.email)) {
      return json({ ok: false, error: 'DUPLICATE', msg: 'لديك تقديم قيد المعالجة بالفعل.' });
    }

    var code = d.code || generateCode();

    // حفظ الملفّ الصوتي في درايف
    var fileUrl = '';
    if (d.audio && d.audio.indexOf('base64,') > -1) {
      try {
        var parts = d.audio.split('base64,');
        var meta  = parts[0];
        var mime  = (meta.match(/data:([^;]+)/) || [])[1] || 'audio/webm';
        var ext   = mime.indexOf('mp4') > -1 ? 'm4a' : (mime.indexOf('ogg') > -1 ? 'ogg' : 'webm');
        var bytes = Utilities.base64Decode(parts[1]);
        var blob  = Utilities.newBlob(bytes, mime, code + '_' + safeName(d.name) + '.' + ext);
        var file  = DriveApp.getFolderById(CONFIG.FOLDER_ID).createFile(blob);
        // الملفّ يبقى خاصّاً — لا يُشارَك علناً
        fileUrl = file.getUrl();
      } catch (audioErr) {
        fileUrl = 'خطأ في حفظ الصوت: ' + audioErr;
      }
    }

    var m = d.metrics || {};
    var row = [
      new Date(), code, d.name, "'" + d.phone, d.email, d.country, d.city || '',
      d.category || '', d.level || '', d.goal || '', d.when || '',
      m.snr || '', m.level || '', m.range || '', m.semitones || '',
      m.breath || '', m.pauses || '', m.duration || '',
      fileUrl, d.marketing ? 'نعم' : 'لا', 'جديد', '', ''
    ];

    SpreadsheetApp.openById(CONFIG.SHEET_ID)
      .getSheetByName(CONFIG.SHEET_NAME).appendRow(row);

    notify(d, code, fileUrl);

    return json({ ok: true, code: code, remaining: left - 1 });

  } catch (err) {
    return json({ ok: false, error: 'SERVER', msg: String(err) });
  }
}

/* ─────────── مساعدات ─────────── */
function json(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function generateCode() {
  return 'KS-VC-' + Math.floor(1000 + Math.random() * 8999);
}

function safeName(s) {
  return String(s).replace(/[^\u0600-\u06FFa-zA-Z0-9]+/g, '_').substring(0, 30);
}

function sheet_() {
  return SpreadsheetApp.openById(CONFIG.SHEET_ID).getSheetByName(CONFIG.SHEET_NAME);
}

function remainingThisWeek() {
  var sh = sheet_();
  var last = sh.getLastRow();
  if (last < 2) return CONFIG.WEEKLY_CAP;

  var now = new Date();
  var day = now.getDay();                 // 0 = الأحد
  var start = new Date(now);
  start.setDate(now.getDate() - day);     // بداية الأسبوع: الأحد
  start.setHours(0, 0, 0, 0);

  var stamps = sh.getRange(2, 1, last - 1, 1).getValues();
  var n = 0;
  for (var i = 0; i < stamps.length; i++) {
    var t = stamps[i][0];
    if (t instanceof Date && t >= start) n++;
  }
  return Math.max(0, CONFIG.WEEKLY_CAP - n);
}

function isDuplicate(email) {
  var sh = sheet_();
  var last = sh.getLastRow();
  if (last < 2) return false;
  var col = HEADERS.indexOf('البريد') + 1;
  var rows = sh.getRange(2, 1, last - 1, col).getValues();
  var cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000);
  for (var i = rows.length - 1; i >= 0; i--) {
    var t = rows[i][0];
    if (t instanceof Date && t < cutoff) break;
    if (String(rows[i][col - 1]).toLowerCase() === String(email).toLowerCase()) return true;
  }
  return false;
}

function notify(d, code, fileUrl) {
  if (!CONFIG.NOTIFY_EMAIL) return;
  var CAT = { ads:'الإعلانات والترويج', doc:'الوثائقي والسرد',
              dub:'الدبلجة وأداء الشخصيات', corp:'التسجيلات المؤسسية' };
  var GOAL = { g1:'هواية', g2:'دخل إضافي', g3:'تحويل مهني كامل', g4:'متطلَّب وظيفي' };
  var WHEN = { w1:'الفوج القادم', w2:'خلال ثلاثة أشهر', w3:'يستكشف فقط' };

  // أولوية المتابعة: من يريد تحويلاً مهنياً ويبدأ بالفوج القادم أوّلاً
  var hot = (d.goal === 'g3' || d.goal === 'g2') && d.when === 'w1';

  var body =
    (hot ? '★ أولوية متابعة عالية\n\n' : '') +
    'رمز التقييم: ' + code + '\n' +
    'الاسم: ' + d.name + '\n' +
    'الواتساب: ' + d.phone + '\n' +
    'البريد: ' + d.email + '\n' +
    'الدولة: ' + d.country + (d.city ? ' — ' + d.city : '') + '\n\n' +
    'المجال: ' + (CAT[d.category] || d.category) + '\n' +
    'الهدف: ' + (GOAL[d.goal] || d.goal) + '\n' +
    'موعد البدء: ' + (WHEN[d.when] || d.when) + '\n\n' +
    'التسجيل: ' + fileUrl;

  MailApp.sendEmail(CONFIG.NOTIFY_EMAIL,
    (hot ? '★ ' : '') + 'تقييم صوتي جديد — ' + d.name + ' (' + code + ')', body);
}
