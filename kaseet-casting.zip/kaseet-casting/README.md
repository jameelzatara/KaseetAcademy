# kaseet-casting — صفحة تجارب الأداء الصوتي

سيرفر Express مستقل يستقبل طلبات المتقدمين، يحفظ ملفات الصوت في قاعدة بيانات PostgreSQL، ويرسل إشعار إيميل للإدارة عند كل تقديم. لوحة إدارة محمية بكلمة مرور.

---

## المتطلبات

- **Node.js 20+**
- **PostgreSQL** — يوفّرها Replit تلقائياً عند إضافة قاعدة بيانات
- **حساب Brevo** — للإيميلات (مجاني حتى 300 رسالة/يوم)

---

## التثبيت في Repl جديد

### 1. أنشئ Repl جديداً
- اختر **Node.js** كنوع المشروع
- أو استورد هذا الـ zip مباشرة

### 2. انسخ الملفات
ارفع محتوى هذا الـ zip إلى جذر المشروع.

### 3. ثبّت الحزم
```bash
npm install
```

### 4. أضف متغيرات البيئة
في **Replit → Secrets** أضف المفاتيح التالية (انظر `.env.example`):

| المفتاح | الوصف |
|---|---|
| `DATABASE_URL` | يُضاف تلقائياً عند إضافة PostgreSQL في Replit |
| `ADMIN_PASSWORD` | كلمة مرور لوحة الإدارة — اختر كلمة قوية |
| `BREVO_API_KEY` | من حساب Brevo → SMTP & API → API Keys |
| `ADMIN_EMAIL` | الإيميل الذي يستقبل إشعارات التقديمات |
| `SENDER_EMAIL` | إيميل المُرسِل (مُفعَّل في Brevo) |
| `SESSION_SECRET` | نص عشوائي طويل (64 حرف) |
| `CASTING_BASE_URL` | رابط الموقع الكامل، مثل `https://casting.kaseet.com` |

### 5. أضف قاعدة البيانات
في Replit: **Tools → Database → Create Database**  
سيُضاف `DATABASE_URL` تلقائياً كـ Secret.

### 6. شغّل السيرفر
```bash
npm run dev
```

---

## أوامر npm

| الأمر | الوصف |
|---|---|
| `npm run dev` | تطوير مع إعادة تشغيل تلقائي |
| `npm run build` | بناء ملفات الإنتاج في `dist/` |
| `npm start` | تشغيل الإنتاج (بعد Build) |

---

## الصفحات

| الرابط | الوصف |
|---|---|
| `/` | نموذج التقديم |
| `/admin` | تسجيل الدخول للوحة الإدارة |
| `/admin/dashboard` | عرض جميع التقديمات |
| `/admin/audio/:id` | تشغيل أو تحميل تسجيل صوتي |
| `/admin/export.csv` | تصدير البيانات (UTF-8 BOM) |
| `/healthz` | فحص صحة السيرفر |

---

## النشر على Replit (Autoscale)

1. من Replit: **Deploy → Autoscale**
2. **Build command:** `npm run build`
3. **Run command:** `node --enable-source-maps dist/index.mjs`
4. بعد النشر ستحصل على رابط `*.replit.app`

### ربط النطاق casting.kaseet.com
في DNS المسؤول عن `kaseet.com` أضف:
```
casting    CNAME    <your-repl-name>.replit.app
```
ثم في Replit Deployment → Custom Domains أضف `casting.kaseet.com`.

---

## بنية الملفات

```
kaseet-casting/
├── src/
│   ├── index.ts          ← نقطة الدخول (Express)
│   ├── db.ts             ← قاعدة البيانات (schema: casting)
│   ├── email.ts          ← إشعارات البريد عبر Brevo
│   ├── routes/
│   │   ├── submit.ts     ← معالج الإرسال (deadline، rate-limit، validation)
│   │   └── admin.ts      ← لوحة الإدارة + CSV + Audio
│   └── views/
│       └── page.html     ← نموذج التقديم الكامل
├── build.mjs             ← esbuild للإنتاج
├── tsconfig.json
├── package.json
└── .env.example
```

---

## ميزات الأمان

- **Deadline** — يُرفض أي إرسال بعد 20 أغسطس 2026 الساعة 20:00 عمّان (server-side)
- **Honeypot** — حقل مخفي يصيد البوتات
- **Rate Limit** — 3 تقديمات كحد أقصى لكل IP في الساعة
- **File Validation** — MP3/WAV فقط، بحد أقصى 25 MB
- **Session Auth** — لوحة الإدارة محمية بجلسة HTTP-Only

---

## قاعدة البيانات

جدول واحد `casting.submissions` في schema مستقل `casting` — لا يتداخل مع أي قاعدة بيانات أخرى.  
يُنشأ الـ schema والجدول تلقائياً عند أول تشغيل.
